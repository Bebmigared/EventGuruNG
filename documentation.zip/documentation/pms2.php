<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
<style>
 table, th, td {
  border: 1px solid black;
  padding-left: 10px;
}
</style>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">Preventive Maintenance Software - Developer Document</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="pms.php" title="hotel management">Preventive Maintenance Software</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/hotel.png" alt="HR Core Article Image" />
</div>

<div class="blog-item-body">

<h2 id="introduction" class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">
<p><img class="alignleft" src="images/1/hotelApp_shoot/landingpage3.PNG" alt="PMS Sign In" />Preventive maintenance is maintenance exercise that is regularly performed on a piece of equipment to lessen the likelihood of it failing. It is performed while the equipment is still working so that it does not break down unexpectedly. The software also includes tracking system. The URL for PMS is <a href="https://www.smoothtracker.com/pms">https://www.smoothtracker.com/pms</a>. You will be required to enter your details then login.</p>

<br><br>
<h2 class="blog-item-title" id="task_status"><strong>TASK STATUS</strong></h2>
 
<table>
<thead>
<tr><th>Modules</th><th>Status</th></tr>
</thead>
<tbody>
<tr><td>Asset</td><td>completed</td></tr>
<tr><td>My job Order</td><td>completed</td></tr>
<tr><td>Document</td><td>completed</td></tr>
<tr><td>Report</td><td>completed</td></tr>
<tr><td>Tracking</td><td>completed</td></tr>
</tbody>
</table>

</div>
</div>
</div>
</article>

<h3 id="breakdown"><strong>Code breakdown with language used</strong></h3>
<p><strong>Programming language:</strong> PHP, JavaScript, JQuery 
<br><strong> Database: MySQL</strong>
<br><strong> Version: 1.0.0 </strong>
<br><strong>System requirement:</strong> Browser compatibility: chrome, safari, internet explorer. 
<br> <strong>Processor Speed:</strong> Minimum Requirement, Pentium 4, 3.2 GHz or Power PC G5, 2.0 GHz. 
<br><strong>Memory:</strong> Minimum of 512 MB.</p>


<h3 id="db_structure"><strong>Database Structure</strong></h3>
<h3>Table structure for table  <i> assets</i></h3>
<p>
CREATE TABLE assets ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, serial_no varchar(255) COLLATE utf8_unicode_ci NOT NULL, department varchar(255) COLLATE utf8_unicode_ci NOT NULL, status smallint(6) NOT NULL DEFAULT '1', created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL, category varchar(255) COLLATE utf8_unicode_ci NOT NULL, user_id tinyint(4) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<br>
<h3>Table structure for table   <i> districts</i></h3>
<p>CREATE TABLE districts ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, location varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, status smallint(6) NOT NULL DEFAULT '1', user_id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>

<h3>Table structure for table  <i> documents</i></h3>
CREATE TABLE documents ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, pix varchar(255) COLLATE utf8_unicode_ci NOT NULL, status smallint(6) NOT NULL DEFAULT '1', expiry_date date NOT NULL, vehicle_id int(10) UNSIGNED DEFAULT NULL COMMENT 'A vehicle id', user_id tinyint(4) NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;</p>

<h3>Table structure for table  <i> drivers</i></h3>
<p>
CREATE TABLE drivers ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, pix varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, phone varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, email varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, status smallint(6) NOT NULL DEFAULT '1', vehicle_id int(10) UNSIGNED DEFAULT NULL COMMENT 'A vehicle id', expiry_date date DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>


<h3>Table structure for table  <i> installers</i></h3>
<p>
CREATE TABLE installers ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, phone varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table <i> item_schedules</i> </h3>
<p>
CREATE TABLE item_schedules ( id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table <i> job_orders </i></h3>
<p>
CREATE TABLE job_orders ( id int(10) UNSIGNED NOT NULL, installer_id int(10) UNSIGNED NOT NULL, user_id int(10) UNSIGNED NOT NULL, asset_id int(10) UNSIGNED NOT NULL, spare_part varchar(255) COLLATE utf8_unicode_ci NOT NULL, status varchar(255) COLLATE utf8_unicode_ci NOT NULL, date date DEFAULT NULL, price double DEFAULT NULL, maintenace_interval varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, services varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, due_date date DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> job_order_vs </i></h3>
<p>
CREATE TABLE job_order_vs ( id int(10) UNSIGNED NOT NULL, user_id int(10) UNSIGNED NOT NULL, vehicle_id int(10) UNSIGNED NOT NULL, spare_part varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, services varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, price double DEFAULT NULL, status varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, date date DEFAULT NULL, maintenace_interval varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, due_date date DEFAULT NULL, installer varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table <i> migrations </i></h3>
<p>
CREATE TABLE migrations ( id int(10) UNSIGNED NOT NULL, migration varchar(255) COLLATE utf8_unicode_ci NOT NULL, batch int(11) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table <i> password_resets </i></h3>
<p>
CREATE TABLE password_resets ( email varchar(255) COLLATE utf8_unicode_ci NOT NULL, token varchar(255) COLLATE utf8_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3> Table structure for table  <i> settings </i></h3>
<p>
CREATE TABLE settings ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, category varchar(255) COLLATE utf8_unicode_ci NOT NULL, user_id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table   <i> users </i></h3>
<p>
CREATE TABLE users ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, email varchar(255) COLLATE utf8_unicode_ci NOT NULL, password varchar(255) COLLATE utf8_unicode_ci NOT NULL, company varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, admin smallint(6) NOT NULL DEFAULT '0', district varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL, status tinyint(4) DEFAULT '1', remember_token varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>

<h3>Table structure for table  <i> vehicles </i></h3>
<p>
CREATE TABLE vehicles ( id int(10) UNSIGNED NOT NULL, make varchar(255) COLLATE utf8_unicode_ci NOT NULL, platenumber varchar(255) COLLATE utf8_unicode_ci NOT NULL, status smallint(6) NOT NULL DEFAULT '1', model varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, ladder_carrier varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, year varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, type varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, chasis varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, district varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, ain varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, branding varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, user_id tinyint(4) NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> vendors </i></h3>
<p>
CREATE TABLE vendors ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, status smallint(6) NOT NULL DEFAULT '1', user_id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<br><br>
<hr>
<p>
<strong> COPYRIGHT:</strong>

All titles, source codes, and other intellectual property rights in and to the SOFTWARE (including but not limited to any images, icons, button, design elements, video, audio, text and incorporated into the SOFTWARE), the accompanying printed materials, and any copies of the SOFTWARE, are owned by ICS outsourcing Limited.
</p>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="main-sidebar">

<div class="main-sidebar-container">

<div class="widget-block-container">
<div class="widget-block-title">
<h6>HOTEL MANAGEMENT Documents</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="pms.php" class="blog-item-small-title">HOTEL MANAGEMENT User Manual</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="pms2.php"  class="blog-item-small-title">HOTEL MANAGEMENT Developer Document</a>
</div>
</li>
</ul>
</div>
</div>

<div class="widget-block widget-block-posts">

<div class="widget-block-container">

<div class="widget-block-title">
<h6>Page Sections</h6>
</div>

<div class="widget-block-body">

<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#introduction" class="blog-item-small-title">Introduction</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#features"  class="blog-item-small-title">Features</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#assets"  class="blog-item-small-title">Assets</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#job_order"  class="blog-item-small-title">My Job Order</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#document"  class="blog-item-small-title">Documents</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#tracking"  class="blog-item-small-title">Tracking</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#report"  class="blog-item-small-title">Report</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#settings"  class="blog-item-small-title">Settings</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#vendors"  class="blog-item-small-title">Vendors</a>
</div>
</li>




</ul>
</div>
</div>


</div>

</div>
</div>

</div>
</div>
</div>

<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>