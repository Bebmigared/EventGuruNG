<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
<style>
 table, th, td {
  border: 1px solid black;
  padding-left: 10px;
}
</style>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">Customer Relationship Management - Developer Document</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="crm.php" title="Customer Relationship management">Customer Relationship Management</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/hotel.png" alt="CRM Article Image" />
</div>

<div class="blog-item-body">

<h2 id="introduction" class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">
<p><img class="alignleft" src="images/1/hotelApp_shoot/landingpage3.PNG" />Customer Relationship Management (CRM) is a combination of strategies and technology that is used to analyse and manage customer interactions throughout the customer lifecycle so as to improve customer service relationship. <a href="https://www.hrcore.ng/CRM">https://www.hrcore.ng/CRM</a></p>
<br><br>
<h2 class="blog-item-title" id="task_status"><strong>TASK STATUS</strong></h2>
 
<table>
<thead>
<tr><th>Modules</th><th>Status</th></tr>
</thead>
<tbody>
<tr><td>Dashboard</td><td>completed</td></tr>
<tr><td>Profile</td><td>completed</td></tr>
<tr><td>Clients</td><td>completed</td></tr>
<tr><td>Task</td><td>completed</td></tr>
<tr><td>User</td><td>completed</td></tr>
<tr><td>Leads</td><td>completed</td></tr>
<tr><td>Department</td><td>completed</td></tr>
</tbody>
</table>

</div>
</div>
</div>
</article>

<h3 id="breakdown"><strong>Code breakdown with language used</strong></h3>
<p><strong>Programming language:</strong> PHP, JavaScript, JQuery 
<br><strong> Database: MySQL</strong>
<br><strong> Version: 1.0.0 </strong>
<br><strong>System requirement:</strong> Browser compatibility: chrome, safari, internet explorer. 
<br> <strong>Processor Speed:</strong> Minimum Requirement, Pentium 4, 3.2 GHz or Power PC G5, 2.0 GHz. 
<br><strong>Memory:</strong> Minimum of 512 MB.</p>


<h3 id="db_structure"><strong>Database Structure</strong></h3>
<h3>Table structure for table  <i> activity_log</i></h3>
<p>
CREATE TABLE activity_log ( id int(10) UNSIGNED NOT NULL, user_id int(11) DEFAULT NULL, text varchar(255) COLLATE utf8_unicode_ci NOT NULL, source_type varchar(255) COLLATE utf8_unicode_ci NOT NULL, source_id int(11) DEFAULT NULL, ip_address varchar(64) COLLATE utf8_unicode_ci NOT NULL, action varchar(255) COLLATE utf8_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<br>
<h3>Table structure for table    <i> clients</i></h3>
<p>CREATE TABLE clients ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, email varchar(255) COLLATE utf8_unicode_ci NOT NULL, primary_number varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, secondary_number varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, address varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, zipcode varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, city varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, company_name varchar(255) COLLATE utf8_unicode_ci NOT NULL, vat varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, industry varchar(255) COLLATE utf8_unicode_ci NOT NULL, company_type varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, user_id int(10) UNSIGNED NOT NULL, industry_id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>

<h3>Table structure for table  <i> comments</i></h3>
<p>CREATE TABLE comments ( id int(10) UNSIGNED NOT NULL, description text COLLATE utf8_unicode_ci NOT NULL, source_id int(10) UNSIGNED NOT NULL, source_type varchar(255) COLLATE utf8_unicode_ci NOT NULL, user_id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

<h3>Table structure for table   <i> departments</i></h3>
<p>
CREATE TABLE departments ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, description text COLLATE utf8_unicode_ci, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>


<h3>Table structure for table <i> department_user</i></h3>
<p>
CREATE TABLE department_user ( id int(10) UNSIGNED NOT NULL, department_id int(10) UNSIGNED NOT NULL, user_id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> documents</i> </h3>
<p>
CREATE TABLE documents ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, size varchar(255) COLLATE utf8_unicode_ci NOT NULL, path varchar(255) COLLATE utf8_unicode_ci NOT NULL, file_display varchar(255) COLLATE utf8_unicode_ci NOT NULL, client_id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table   <i> industries </i></h3>
<p>
CREATE TABLE industries ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table   <i> integrations </i></h3>
<p>
CREATE TABLE integrations ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, client_id int(11) DEFAULT NULL, user_id int(11) DEFAULT NULL, client_secret int(11) DEFAULT NULL, api_key varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, api_type varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, org_id varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table <i> invoices </i></h3>
<p>
CREATE TABLE invoices ( id int(10) UNSIGNED NOT NULL, status varchar(255) COLLATE utf8_unicode_ci NOT NULL, invoice_no varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, sent_at datetime DEFAULT NULL, payment_received_at datetime DEFAULT NULL, due_at datetime DEFAULT NULL, client_id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table <i> invoice_lines </i></h3>
<p>
CREATE TABLE invoice_lines ( id int(10) UNSIGNED NOT NULL, title varchar(255) COLLATE utf8_unicode_ci NOT NULL, comment text COLLATE utf8_unicode_ci NOT NULL, price int(11) NOT NULL, invoice_id int(10) UNSIGNED NOT NULL, type varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, quantity int(11) DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table   <i> leads </i></h3>
<p>
CREATE TABLE leads ( id int(10) UNSIGNED NOT NULL, title varchar(255) COLLATE utf8_unicode_ci NOT NULL, description text COLLATE utf8_unicode_ci NOT NULL, status int(11) NOT NULL, user_assigned_id int(10) UNSIGNED NOT NULL, client_id int(10) UNSIGNED NOT NULL, user_created_id int(10) UNSIGNED NOT NULL, contact_date datetime NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> migrations </i></h3>
<p>
CREATE TABLE migrations ( id int(10) UNSIGNED NOT NULL, migration varchar(255) COLLATE utf8_unicode_ci NOT NULL, batch int(11) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> notifications </i></h3>
<p>
CREATE TABLE notifications ( id char(36) COLLATE utf8_unicode_ci NOT NULL, type varchar(255) COLLATE utf8_unicode_ci NOT NULL, notifiable_id int(10) UNSIGNED NOT NULL, notifiable_type varchar(255) COLLATE utf8_unicode_ci NOT NULL, data text COLLATE utf8_unicode_ci NOT NULL, read_at timestamp NULL DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> password_resets </i></h3>
<p>
CREATE TABLE password_resets ( email varchar(255) COLLATE utf8_unicode_ci NOT NULL, token varchar(255) COLLATE utf8_unicode_ci NOT NULL, created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> permissions </i></h3>
<p>
CREATE TABLE permissions ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, display_name varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, description varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> permission_role </i></h3>
<p>
CREATE TABLE permission_role ( permission_id int(10) UNSIGNED NOT NULL, role_id int(10) UNSIGNED NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

</p>
<h3>Table structure for table  <i> roles </i></h3>
<p>
CREATE TABLE roles ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, display_name varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, description varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
</p>
<h3>Table structure for table  <i> role_user </i></h3>
<p>
CREATE TABLE role_user ( user_id int(10) UNSIGNED NOT NULL, role_id int(10) UNSIGNED NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

</p>
<h3>Table structure for table  <i> settings </i></h3>
<p>
CREATE TABLE settings ( id int(10) UNSIGNED NOT NULL, task_complete_allowed int(11) NOT NULL, task_assign_allowed int(11) NOT NULL, lead_complete_allowed int(11) NOT NULL, lead_assign_allowed int(11) NOT NULL, time_change_allowed int(11) NOT NULL, comment_allowed int(11) NOT NULL, country varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, company varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

</p>
<h3>Table structure for table  <i> tasks </i></h3>
<p>
CREATE TABLE tasks ( id int(10) UNSIGNED NOT NULL, title varchar(255) COLLATE utf8_unicode_ci NOT NULL, description text COLLATE utf8_unicode_ci NOT NULL, status int(11) NOT NULL, user_assigned_id int(10) UNSIGNED NOT NULL, user_created_id int(10) UNSIGNED NOT NULL, client_id int(10) UNSIGNED NOT NULL, invoice_id int(10) UNSIGNED DEFAULT NULL, deadline date NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

</p>
<h3>Table structure for table  <i> users </i></h3>
<p>
CREATE TABLE users ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8_unicode_ci NOT NULL, email varchar(255) COLLATE utf8_unicode_ci NOT NULL, password varchar(60) COLLATE utf8_unicode_ci NOT NULL, address varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, work_number varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, personal_number varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, image_path varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL, remember_token varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

</p>
<h2>Indexes for table activity_log</h2>
<h3>ALTER TABLE activity_log ADD PRIMARY KEY (id);</h3>
<p>
Indexes for table clients -- ALTER TABLE clients ADD PRIMARY KEY (id), ADD UNIQUE KEY clients_email_unique (email), ADD KEY clients_user_id_foreign (user_id), ADD KEY clients_industry_id_foreign (industry_id);
</p>
<p>
Indexes for table comments -- ALTER TABLE comments ADD PRIMARY KEY (id), ADD KEY comments_source_id_source_type_index (source_id,source_type), ADD KEY comments_user_id_foreign (user_id);
</p>
<br><br>
<hr>
<p>
<strong> COPYRIGHT:</strong>

All titles, source codes, and other intellectual property rights in and to the SOFTWARE (including but not limited to any images, icons, button, design elements, video, audio, text and incorporated into the SOFTWARE), the accompanying printed materials, and any copies of the SOFTWARE, are owned by ICS outsourcing Limited.
</p>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="main-sidebar">

<div class="main-sidebar-container">

<div class="widget-block-container">
<div class="widget-block-title">
<h6>Customer Relationship Management Documents</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="crm.php" class="blog-item-small-title">Customer Relationship Management User Manual</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="crm2.php"  class="blog-item-small-title">Customer Relationship Management Developer Document</a>
</div>
</li>
</ul>
</div>
</div>

<div class="widget-block widget-block-posts">

<div class="widget-block-container">

<div class="widget-block-title">
<h6>Page Sections</h6>
</div>

<div class="widget-block-body">

<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#introduction" class="blog-item-small-title">Introduction</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#task_status"  class="blog-item-small-title">Task Status</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#dashboard"  class="blog-item-small-title">Code Breakdown</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#db_structure"  class="blog-item-small-title">Database Structure</a>
</div>
</li>
</ul>
</div>
</div>


</div>

</div>
</div>

</div>
</div>
</div>

<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>