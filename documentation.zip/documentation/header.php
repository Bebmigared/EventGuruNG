<header class="header-section fixed-header">

<div class="header-section-container">

<div class="header-menu">

<div class="header-menu-container">

<nav class="navbar">

<div class="container">

<div class="row">

<div class="col-md-12">

 <div class="navbar-header">
<a href="index.pgp" class="navbar-brand" title="ICS">
<img src="images/logo.png" alt="ICS Logo" />
</a>
</div>

<ul class="header-btns">

<li class="header-lang-btn">
<a href="signing/logout.php" title="English">ADMIN<i class="fa fa-angle-down"></i></a>

<nav class="header-language-menu">
<ul>
<li>
<a href="signing/logout.php" title="logout">LOGOUT
</a>
</li>
</ul>
</nav>
</li>

</ul>

<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
<span class="menu-wd">Menu</span>
<span class="lines-wrapper"><i class="lines"></i></span>
</button>

<div class="navbar-collapse collapse">
<ul class="nav navbar-nav">
<li>
<a href="index.php">Home</a>
</li>
<li>
<a href="hrcore.php">HRcore</a>
<ul class="submenu">
<li>
<a href="hrcore.php">HRcore User Manual</a>
</li>
<li>
<a href="hrcore2.php">HRcore Developer Document</a>

</li>
<li>
<a href="#">Events</a>
</li>
</ul>
</li>
<li>
<a href="hma.php">Hotel Mgmt</a>
<ul class="submenu">
<li><a href="hma.php">Hotel Management User Manual</a></li>
<li><a href="hma2.php">Hotel Management Developers Manual</a></li>
</ul>
</li>
<li>
<a href="pms.php">PMS</a>

<ul class="submenu">
<li><a href="pms.php">Preventive Maintenance Software User Manual</a></li>
<li><a href="pms2.php">PMS Developer Document</a></li>
</ul>

</li>
<li>
<a href="crm.php">CRM</a>
<ul class="submenu">
<li><a href="crm.php">CRM User Manual</a></li>
<li><a href="crm2.php">CRM Developer Document</a></li>
</ul>
</li>
<li>
<a href="fsa.php">Field Sales App</a>
<ul class="submenu">
<li><a href="fsa.php">Field Sales App User Manual</a></li>
</ul>
</li>
<li>
<a href="ema.php">Event Mgmt</a>
<ul class="submenu">
<li><a href="ema.php">Event Management User Manual</a></li>
</ul>
</li>
<li>
<a href="smoothride.php">SmoothRide</a>

<ul class="submenu">
<li><a href="smoothride.php">SmoothRide User Manual</a></li>
</ul>

</li>
</ul>
</div>

</div>
</div>
</div>
</nav>


</div>
</div>
</div>
</header>