<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">Field Sales - User Manual</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="ema.php" title="Blog">Field Sales</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/fsa.png" alt="Field Sales Article Image" />
</div>

<div class="blog-item-body">

<h2 id="introduction" class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">

<p>Field sales is the process by which companies visit leads and sell to them in <a href="http://person.it/">person.It</a> enables the sales manager keep track of all their sales representatives activities. Field Sales is in 2 section, the web application for the admin and mobile application for the sales representative.Some of the features of Field sales application include route plane. inventory,orders,analytics,outlets, schedule .The URL for the admin is <a href="http://salesmanager.ng/login">http://salesmanager.ng/login</a>.</p>
<h2 class="blog-item-title" id="process"><strong>PROCESS FLOW</strong></h2>
<p><img src="images/1/FieldSales/process_flow.PNG" alt="process_flow"></p>

<h2 class="blog-item-title" id="admin_menu"><strong>ADMIN MENU</strong></h2>
<p><img src="images/1/FieldSales/admin_menu.PNG" alt="admin_menu"></p>

<h2 class="blog-item-title" id="admin_profile"><strong>ADMIN PROFILE</strong></h2>
<p><img src="images/1/FieldSales/process_flow.PNG" alt="process_flow"></p>

<h2 class="blog-item-title" id="dashboard"><strong>DASHBOARD</strong></h2>
<p>On the dashboard, you have the overview of all the activities going in the application</p>
<p><img src="images/1/FieldSales/admin_dashboard.PNG" alt="admin_dashboard"></p>
<p><img src="images/1/FieldSales/admin_dashboard2.PNG" alt="admin_dashboard2"></p>

<h2 class="blog-item-title" id="route"><strong>ROUTE PLANS</strong></h2>
<p>In the route plan, sales manager can view all the sales representatives location to be visited.</p>
<p><img src="images/1/FieldSales/route_plan.PNG" alt="route_plan"></p>
<p>In the route summary, the sales manager can filter the route plan of their  sales representative  individually.</p>
<p><img src="images/1/FieldSales/route_summary.PNG" alt="route_summary"></p>

<h2 class="blog-item-title" id="inventory"><strong>INVENTORY</strong></h2>
<p>In the inventory, the sales manager will be able to add inventory and view inventory.</p>
<p><img src="images/1/FieldSales/add_inventory.PNG" alt="add_inventory"></p>
<p><img src="images/1/FieldSales/add_inventory2.PNG" alt="add_inventory2"></p>
<p><img src="images/1/FieldSales/inventory.PNG" alt="inventory"></p>

<h2 class="blog-item-title" id="orders"><strong>ORDERS</strong></h2>
<p>The sales manager keep track of all the orders logged in by the sales representative.</p>
<p><img src="images/1/FieldSales/admin_order_request.PNG" alt="admin_order_request"></p>
<p>In the order summary, the sales manager will be able to filter all the orders logged in by each sales representative and also by the month.</p>
<p><img src="images/1/FieldSales/order_summary.PNG" alt="order_summary"></p>

<h2 class="blog-item-title" id="briefs"><strong>BRIEFS</strong></h2>
<p>For the briefs menu, if the sales manager has any information to pass to the sales representative it is done on this platform and if the sales representative has any information, it is done on this platform.</p>
<p><img src="images/1/FieldSales/brief.PNG" alt="brief"></p>

<h2 class="blog-item-title" id="outlet"><strong>OUTLET</strong></h2>
<p>The outlets comprises of all the shops, stores and supermarket they sell to</p>
<p><img src="images/1/FieldSales/outlets.PNG" alt="outlets"></p>

<h2 class="blog-item-title" id="sales_rep"><strong>SALES REP</strong></h2>
<p>The sales manager can add sales rep and view all the sales rep. Also the sales manager can assign quantity of product to each sales representative.</p>
<p><img src="images/1/FieldSales/add_sales_rep.PNG" alt="add_sales_rep"></p>
<p><img src="images/1/FieldSales/sales_rep_add_2.PNG" alt="sales_rep_add_2"></p>
<p><img src="images/1/FieldSales/sales_rep.PNG" alt="sales_rep"></p>
<p><img src="images/1/FieldSales/sales_rep_inventory.PNG" alt="sales_rep_inventory"></p>

<h2 class="blog-item-title" id="sales"><strong>SALES</strong></h2>
<p>In the sales platform, the sales manager can view the monthly sales report of every sales represenative.</p>
<p><img src="images/1/FieldSales/sales_report.PNG" alt="sales_report"></p>
<p><img src="images/1/FieldSales/sales_summary.PNG" alt="sales_summary"></p>

<h2 class="blog-item-title" id="schedule"><strong>SCHEDULE</strong></h2>
<p>The sales manager can view all the sales representatives schedule for the day and also filter it based on the month or sales representative name.</p>
<p><img src="images/1/FieldSales/schedule.PNG" alt="schedule"></p>
<p><img src="images/1/FieldSales/schedule_summary.PNG" alt="schedule_summary"></p>

<h2 class="blog-item-title" id="research"><strong>MARKET RESEARCH</strong></h2>
<p>The sales manager can view all the market research made by the sales representative
<img src="images/1/FieldSales/market_research.PNG" alt="market_research"></p>



</div>
</div></div>
</article></div>



</div>
</div>
</div>



</div>
</div>
</div>
</div>

<!--SideBar Starts-->
<div class="main-sidebar">

<div class="main-sidebar-container">
<div class="widget-block widget-block-posts">

<div class="widget-block-container">
<div class="widget-block-title">
<h6>FIELD SALES Documents</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="smoothride.php" class="blog-item-small-title">FIELD SALES User Manual</a>
</div>
</li>

</ul>
</div>
</div>


<div class="widget-block-container">
<div class="widget-block-title">
<h6>Page Sections</h6>
</div>

<div class="widget-block-body">

<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#introduction" class="blog-item-small-title">INTRODUCTION</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#process"  class="blog-item-small-title">PROCESS FLOW</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#admin_menu"  class="blog-item-small-title">ADMIN MENU</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#admin_profile"  class="blog-item-small-title">ADMIN PROFILE</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#dashboard"  class="blog-item-small-title">DASHBOARD</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#route"  class="blog-item-small-title">ROUTE PLANS</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#inventory"  class="blog-item-small-title">INVENTORY</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#orders"  class="blog-item-small-title">ORDERS</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#briefs"  class="blog-item-small-title">BRIEFS</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#outlet"  class="blog-item-small-title">OUTLET</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#sales_rep"  class="blog-item-small-title">SALES REP</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#sales"  class="blog-item-small-title">SALES</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#schedule"  class="blog-item-small-title">SCHEDULE</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#research"  class="blog-item-small-title">MARKET RESEARCH</a>
</div>
</li>


</ul>
</div>
</div>

</div>

</div>
</div>
<!--Sidebar Ends-->

</div>
</div>
</div>
</div>



<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>