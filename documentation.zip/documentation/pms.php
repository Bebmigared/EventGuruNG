<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">Preventive maintenance - User Manual</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="hma.php" title="Blog">Preventive maintenance</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/pms.png" alt="PMS Article Image" />
</div>

<div class="blog-item-body">

<h2 id="introduction" class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">
<p>Preventive maintenance is maintenance exercise that is regularly performed on a piece of equipment to lessen the likelihood of it failing. It is performed while the equipment is still working so that it does not break down unexpectedly. The software also includes tracking system. The URL for PMS is <a href="https://www.smoothrepairs.com/pms">https://www.smoothrepairs.com/pms</a>. You will be required to enter your details then login.
FEATURES OF PREVENTIVE MAINTAINANCE SOFTWARE(PMS)</p>
<blockquote>
<p>Outbreaks are either a Matter of NEGLECT or POOR PREVENTIVE MAINTENANCE. </p>
<footer>David Hamm</footer>
</blockquote>


<p>Below is the dashboard of the PMS. It contains an overview of the essential in the software</p>
<p><img src="images/1/pms/dashboard.PNG" alt="dashboard">
</p>

<h2>FEATURES of PMS</h2>
<p><img src="images/1/pms/menu_page.PNG" alt="menu_page"></p>
<h2 id="assets">ASSETS</h2>
<p>For the assets platform, all company asset is to be registered like vehicles, air conditioner, generators and other. You can add assets and also view</p>
<p><img src="images/1/pms/ac_assest.PNG" alt="ac_assest"><br><br>
<img src="images/1/pms/vehicle_asset.PNG" alt="vehicle_asset"><br><br>
<img src="images/1/pms/add_generator.PNG" alt="add_generator"><br><br>
<img src="images/1/pms/ac_assest.PNG" alt="ac_assest"><br><br>
<img src="images/1/pms/add_ac.PNG" alt="add_ac"></p>

<h2 id="job_order">MY JOB ORDER</h2>
<p>It’s a platform for creating jobs. It includes the installer name, asset, date added, spare part, interval total price and due date.</p>
<p><img src="images/1/pms/createjoborder.PNG" alt="createjoborder"><br><br>
<img src="images/1/pms/joborder_report.PNG" alt="joborder_report"></p>
<h2 id="document">DOCUMENTS</h2>
<p>This allows the uploading and viewing of asset documents</p>
<p><img src="images/1/pms/upload_doc.PNG" alt="documents_img"></p>
<h2 id="tracking">TRACKING</h2>
<p>It’s a device that allows you keep track of all vehicles.</p>
<p><img src="images/1/pms/tracking.PNG" alt="tracking"></p>
<h2 id="report">REPORT</h2>
<p>It allows spooling of data for job order, vehicles, documents, driver. The report can be in either excel, PDF, CSV format or print</p>
<p><img src="images/1/pms/joborder_report.PNG" alt="report"></p>
<h2 id="settings">SETTINGS</h2>
<p>It allows the creation of district and users. </p>
<img src="images/1/pms/create_district.PNG" alt="settings"><br><br>
<img src="images/1/pms/create_users.PNG" alt="settings2">
<h2 id="vendors">VENDORS</h2>
<p>Vendors can view but added but the users. </p>
<img src="images/1/pms/vendor.PNG" alt="vendors"><br><br>
<img src="images/1/pms/new_vendor.PNG" alt="vendors2"><br><br>
<img src="images/1/pms/create_vendors.PNG" alt="vendors3"><br><br>
<h2>NOTE</h2>
<p>For the users, the only action that can be carried out by them is to create vendors</p>

<!--Staff Rights-->
</div>
</div></div>
</article></div>



</div>
</div>
</div>



</div>
</div>
</div>
</div>

<!--SideBar Starts-->
<div class="main-sidebar">

<div class="main-sidebar-container">
<div class="widget-block widget-block-posts">

<div class="widget-block-container">
<div class="widget-block-title">
<h6>PREVENTIVE MAINTAINANCE Documents</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="pms.php" class="blog-item-small-title">PREVENTIVE MAINTAINANCE User Manual</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="pms2.php"  class="blog-item-small-title">PREVENTIVE MAINTAINANCE Developer Document</a>
</div>
</li>
</ul>
</div>
</div>

<div class="widget-block-container">
<div class="widget-block-title">
<h6>PAGE Sections</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#introduction" class="blog-item-small-title">Introduction</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#features"  class="blog-item-small-title">Features</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#assets"  class="blog-item-small-title">Assets</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#job_order"  class="blog-item-small-title">My Job Order</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#document"  class="blog-item-small-title">Documents</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#tracking"  class="blog-item-small-title">Tracking</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#report"  class="blog-item-small-title">Report</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#settings"  class="blog-item-small-title">Settings</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#vendors"  class="blog-item-small-title">Vendors</a>
</div>
</li>




</ul>
</div>
</div>

</div>

</div>
</div>
<!--Sidebar Ends-->

</div>
</div>
</div>
</div>



<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>