<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">Hotel Management - User Manual</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="hma.php" title="Blog">Hotel Management</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/hotel.png" alt="HR Core Article Image" />
</div>

<div class="blog-item-body">

<h2 class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">
<p>Hotel management system is a platform that brings hotels around the world together for easy access to customers.<a href="https://www.hotelanywhere.com/login"> https://www.hotelanywhere.com/login</a></p>
<blockquote>
<p>SERVICE, QUALITY, SATISFACTION, LOYALTY, SUPPORT, COMMUNICATION, FEEDBACK, TRUST. </p>
<footer>Hotel Management</footer>
</blockquote>
<h2 class="blog-item-title" id="admin_settings"><strong>USER LANDING PAGE</strong></h2>
 <p>The user can perform the following actions:.</p>
 
<ol>
    <li>Make reservations</li>
    <li>Search by location, facilities, price, popular hotel</li>
    <li>Give review about a particular hotel</li>
    <li>Subscribe to news letter</li>
    <li>Add a hotel (for hotel owners)</li>
    <li>Contact us</li>
    <li>Access fair deal</li>
    <li>Leave a message</li>
</ol>
<br><br>

<p><img src="images/1/hotelApp_shoot/landingpage1.PNG" alt="alt-text">
<img src="images/1/hotelApp_shoot/landingpage2.PNG" alt="alt-text">
<img src="images/1/hotelApp_shoot/landingpage3.PNG" alt="alt-text">
<img src="images/1/hotelApp_shoot/landingpage4.PNG" alt="alt-text">
<img src="images/1/hotelApp_shoot/landingpage5.PNG" alt="alt-text">
<img src="images/1/hotelApp_shoot/landingpage6.PNG" alt="alt-text">
<img src="images/1/hotelApp_shoot/landingpage7.PNG" alt="alt-text"></p>


<h2><a class="anchor" aria-hidden="true" id="superadmin"></a><a href="#superadmin" aria-hidden="true" class="hash-link"><svg class="hash-link-icon" aria-hidden="true" height="16" version="1.1" viewBox="0 0 16 16" width="16"><path fill-rule="evenodd" d="M4 9h1v1H4c-1.5 0-3-1.69-3-3.5S2.55 3 4 3h4c1.45 0 3 1.69 3 3.5 0 1.41-.91 2.72-2 3.25V8.59c.58-.45 1-1.27 1-2.09C10 5.22 8.98 4 8 4H4c-.98 0-2 1.22-2 2.5S3 9 4 9zm9-3h-1v1h1c1 0 2 1.22 2 2.5S13.98 12 13 12H9c-.98 0-2-1.22-2-2.5 0-.83.42-1.64 1-2.09V6.25c-1.09.53-2 1.84-2 3.25C6 11.31 7.55 13 9 13h4c1.45 0 3-1.69 3-3.5S14.5 6 13 6z"></path></svg></a>SUPERADMIN</h2>
<p>For every hotel on the platform, there is a super admin who enter all the details of their hotel and the branches.</p>
<p>The admin has access to:</p>
<ol>
<li><h3>Dashboard</h3></li>

<p><img src="images/1/hotelApp_shoot/sadmin_dashboard.PNG" alt="alt-text"></p>

<li>
<h3 id="profile">My profile</h3>
<p>
<img src="images/1/hotelApp_shoot/profilepage.PNG" alt="alt-text">
</p></li>

<li><p>
<h3 id="branch">For branch</h3>

<img src="images/1/hotelApp_shoot/editprofile.PNG" alt="alt-text"></p>
</li>
<li>
<p>
<h3 id="add_branch">Add branch</h3>
<img src="images/1/hotelApp_shoot/addbranch.PNG" alt="alt-text"></p>
<p>
</li> 
<li>
<h3 id="view_branch">View branch</h3>
<img src="images/1/hotelApp_shoot/branches.PNG" alt="alt-text">
</p>
</li>
<li>
<p>
<h3 id="modify_branch"> Modify branch</h3>
<img src="images/1/hotelApp_shoot/modifybranchdetail.PNG" alt="alt-text">
</p>
</li>
</ol>

<!--Staff Rights-->
<h2 id="staff">Staff</h2>
<ol>
<li>
<h3 id="add_staff">Add staff</h3>
<p><img src="images/1/hotelApp_shoot/addstaff.PNG" alt="alt-text">
</li>

<li>
<h3 id="view_staff">View staff</h3>
<img src="images/1/hotelApp_shoot/view_staff.PNG" alt="alt-text">
</li>
<li>
<h3 id="modify_staff">Modify staff</h3>
<img src="images/1/hotelApp_shoot/modifystaff.PNG" alt="alt-text"></p>
</li>
</ol>


<h2 id="room">ROOM</h2>
<img src="images/1/hotelApp_shoot/rooms.PNG" alt="alt-text"><br><br>
<ol>
<li>
<h3 id="view_reservation"> View reservation</h3>
<img src="images/1/hotelApp_shoot/reservations.PNG" alt="alt-text">
</li>
<li>
<h3 id="check_in">Check-in customers</h3>
<img src="images/1/hotelApp_shoot/check_guest.PNG" alt="alt-text">
</li>
<li>
<h3 id="check_out">Check-out customers</h3>
<img src="images/1/hotelApp_shoot/checkout_guest.PNG" alt="alt-text">
</li>
<li>
<h3 id="room_category">Add room category</h3>
<img src="images/1/hotelApp_shoot/roomfeature.PNG" alt="alt-text">
</li>
<li>
<h3 id="add_room">Add room</h3>
<img src="images/1/hotelApp_shoot/addroom.PNG" alt="alt-text">
</li>
<li>
<h3 id="add_reservation">Add reservation</h3>
<img src="images/1/hotelApp_shoot/check_availablity.PNG" alt="alt-text">
</li>
<li>
<h3 id="modify_room_category">Modify room category</h3>
<img src="images/1/hotelApp_shoot/roominfo.PNG" alt="alt-text"></p>
</li>
<li>
<h3 id="modify_room">Modify room.</h3></li>
<img src="images/1/hotelApp_shoot/modify_rooms.PNG" alt="alt-text">
</ol>
<p>

<h2 id="restaurant">RESTAURANT</h2>
<ol >
<li>Add restaurant</li>
<li>View reservation</li>
<li>Make reservation</li>
<li>Add fair deal(discount)</li>

<li><strong>Recommend: give recommendation based on user information</strong></li>
</ol>
<p><img src="images/1/hotelApp_shoot/recommend.PNG" alt="alt-text"></p>
</span></div>
</div></div>
</article></div>



</div>
</div>
</div>



</div>
</div>
</div>
</div>

<!--SideBar Starts-->
<div class="main-sidebar">

<div class="main-sidebar-container">
<div class="widget-block widget-block-posts">

<div class="widget-block-container">
<div class="widget-block-title">
<h6>HOTEL MANAGEMENT Documents</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="hma.php" class="blog-item-small-title">HOTEL MANAGEMENT User Manual</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="hma2.php"  class="blog-item-small-title">HOTEL MANAGEMENT Developer Document</a>
</div>
</li>
</ul>
</div>
</div>


<div class="widget-block-container">
<div class="widget-block-title">
<h6>Page Sections</h6>
</div>

<div class="widget-block-body">

<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#introduction" class="blog-item-small-title">Introduction</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#home"  class="blog-item-small-title">Landing Page</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#superadmin"  class="blog-item-small-title">Super Admin</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#dashboard"  class="blog-item-small-title">Dashboard</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#profile"  class="blog-item-small-title">My Profile</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#branch"  class="blog-item-small-title">For Branch</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#add_branch"  class="blog-item-small-title">Add Branch</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_branch"  class="blog-item-small-title">View Branch</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#staff"  class="blog-item-small-title">Staff</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#add_staff"  class="blog-item-small-title">Add Staff</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_staff"  class="blog-item-small-title">View Staff</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#modify_staff"  class="blog-item-small-title">Modify Staff</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#room"  class="blog-item-small-title">Room</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_reservation"  class="blog-item-small-title">View Reservation</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#check_in"  class="blog-item-small-title">Check-in Customers</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#check_out"  class="blog-item-small-title">Check-out Customers</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#room_category"  class="blog-item-small-title">Add Room Category</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#add_room"  class="blog-item-small-title">Add Room</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#add_reservation"  class="blog-item-small-title">Add Reservation</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#room_category"  class="blog-item-small-title">Modify Room Category</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#modify_room"  class="blog-item-small-title">Modify Room</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#restaurant"  class="blog-item-small-title">Restaurant</a>
</div>
</li>

</ul>
</div>
</div>

</div>

</div>
</div>
<!--Sidebar Ends-->

</div>
</div>
</div>
</div>



<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>