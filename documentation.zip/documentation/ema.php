<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">Event Management - User Manual</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="ema.php" title="Event Management">Event Management</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/ema.png" alt="Event Management Article Image" />
</div>

<div class="blog-item-body">

<h2 id="introduction" class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">

<p>Event guru is an application on which people can create event,register for an event,search and connect with vendors, social network  and request for event management service.The URL for event guru is <a href="http://eventguru.ng/">http://eventguru.ng/</a></p>
<blockquote>
<p>EventGuru, Your World of Unlimited Events! </p>
<footer>Product Manager</footer>
</blockquote>
<h2 class="blog-item-title" id="invite"><strong>INVITE/SUBSCRIBE</strong></h2>
<p>User can buy view details of an event and buy ticket if interested. Also view the speakers profile</p>
<p><img src="images/1/event/landing_page.PNG" alt="landing_page"><br><br></p>
<p><img src="images/1/event/book_ticket.PNG" alt="book_ticket"><br><br></p>
<p><img src="images/1/event/book_ticket2.PNG" alt="book_ticket2"><br><br></p>
<p><img src="images/1/event/view_speaker.PNG" alt="view_speaker"><br></p>
<p>One can also create event on the platform .</p>
<p><img src="images/1/event/create_event.PNG" alt="create_event"><br><br></p>
<p><img src="images/1/event/create_event2.PNG" alt="create_event2"><br><br></p>
<p><img src="images/1/event/create_event3.PNG" alt="create_event3"><br><br></p>
<p><img src="images/1/event/create_event4.PNG" alt="create_event4"></p>
<br><br>

<h2 id="f_profile">FACILITATOR PROFILE</h2>
<p><img src="images/1/event/view_speaker.PNG" alt="view_speaker"><br><br></p>
<h2 id="a_profile">ATTENDEE PROFILE</h2>
<p><img src="images/1/event/profile.PNG" alt="profile"><br><br></p>
<p><img src="images/1/event/user_profile.PNG" alt="user_profile"><br><br></p>
<p><img src="images/1/event/profile2.PNG" alt="profile2"><br><br></p>
<p><img src="images/1/event/profile3.PNG" alt="profile3"></p>

<h2 id="networking">SOCIAL NETWORKING</h2>
<p><img src="images/1/event/socialnetwork.PNG" alt="socialnetwork"><br><br></p>

<h2 id="event">SEARCH FOR EVENT</h2>
<p><img src="images/1/event/search_event.PNG" alt="search_event"></p>




</div>
</div></div>
</article></div>



</div>
</div>
</div>



</div>
</div>
</div>
</div>

<!--SideBar Starts-->
<div class="main-sidebar">

<div class="main-sidebar-container">
<div class="widget-block widget-block-posts">

<div class="widget-block-container">
<div class="widget-block-title">
<h6>EVENT MANAGEMENT Documents</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="smoothride.php" class="blog-item-small-title">EVENT MANAGEMENT User Manual</a>
</div>
</li>

</ul>
</div>
</div>


<div class="widget-block-container">
<div class="widget-block-title">
<h6>Page Sections</h6>
</div>

<div class="widget-block-body">

<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#introduction" class="blog-item-small-title">INTRODUCTION</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#invite"  class="blog-item-small-title">INVITE/SUBSCRIBE</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#f_profile"  class="blog-item-small-title">FACILITATOR PROFILE</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#a_profile"  class="blog-item-small-title">ATTENDEE PROFILE</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#networking"  class="blog-item-small-title">SOCIAL NETWORKING</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#event"  class="blog-item-small-title">SEARCH FOR EVENT</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#customer"  class="blog-item-small-title">Customer</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#admin_area"  class="blog-item-small-title">Admin Area</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#mobile"  class="blog-item-small-title">SmoothRide Mobile App</a>
</div>
</li>


</ul>
</div>
</div>

</div>

</div>
</div>
<!--Sidebar Ends-->

</div>
</div>
</div>
</div>



<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>