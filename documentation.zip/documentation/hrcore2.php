<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
<style>
 table, th, td {
  border: 1px solid black;
  padding-left: 10px;
}
</style>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">HR Core - Developer Document</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="hrcore.php" title="HRcore">HR core</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/hrcore.png" alt="HR Core Article Image" />
</div>

<div class="blog-item-body">

<h2 class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">
<p><img class="alignleft" src="images/1/shoot/signIn.PNG" alt="HR Sign In" />HRcore is a flexible software that helps with the day-to-day activities of the company. It includes leave management, appraisal management, requisition system, audit system. The URL to register as an admin is for HRcore is <a href="https://www.hrcore.ng/admin_register"> https://www.hrcore.ng/admin_register </a> while the URL to register as a staff is <a href="https://www.hrcore.ng/register"> https://www.hrcore.ng/register .</a></p>
<br><br>
<h2 class="blog-item-title" id="admin_settings"><strong>SETTINGS</strong></h2>
 <p>In HRcore, the settings are a very important part of the HRcore. In the settings, the admin is first required to setup the system according to their company system specification by filling all fields correctly to enable easy flow of work.</p>
<h3><strong>Admin Settings</strong></h3>
<img src="images/1/shoot/admin_settings.PNG" alt="Admin settings 1"><br>
<img src="images/1/shoot/admin_setting2.PNG" alt="Admin settings 2"><br>
<img src="images/1/shoot/admin_setting3.PNG" alt="Admin settings 3">



<h3 id="staff_settings"><strong>Staff Settings</strong></h3>
<img src="images/1/shoot/staff_setting.PNG" alt="Staff settings 1"><br>
<img src="images/1/shoot/staff_settings2.PNG" alt="Staff settings 2"><br>

<p>Also the staff is also required to fill all fields on the settings for easy flow of request..</p>

<h3 id="dashboard"><strong>Task Status</strong></h3>

<table style="width:50%" style="border: 1px solid black;">
  <tr>
    <td><strong>Models</strong></td>
    <td><strong>Status</strong></td> 
  </tr>
  <tr>
    <td>Leave management system</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>Appraisal system</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>Requisition system</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>Employee information</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>ID card request</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>Staff audit</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>Staff Directory</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>Payroll</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>Permission</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>Dashboard</td>
    <td>Completed</td> 
  </tr>
  <tr>
    <td>KSS Board</td>
    <td>Completed</td> 
  </tr>
</table>

</div>
</div>
</div>
</article>



<h3><strong>Code breakdown with language used</strong></h3>
<p><strong>Programming language:</strong> PHP, JavaScript, JQuery Database: MySQL Version: 1.0.0 
<br><strong>System requirement:</strong> Browser compatibility: chrome, safari, internet explorer. 
<br> <strong>Processor Speed:</strong> Minimum Requirement, Pentium 4, 3.2 GHz or Power PC G5, 2.0 GHz. 
<br><strong>Memory:</strong> Minimum of 512 MB.</p>


<h3><strong>Database Structure</strong></h3>
<h3>Table structure for table <i> appraisal</i></h3>
<p>
CREATE TABLE appraisal ( id int(11) NOT NULL, date_created varchar(50) NOT NULL, period varchar(50) NOT NULL, year varchar(50) NOT NULL, replies int(200) NOT NULL, document_name varchar(255) NOT NULL, document varchar(255) NOT NULL, department varchar(255) NOT NULL, appraisal_data text NOT NULL, admin_id varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<br>
<h3>Table structure for table <i> appraisal_replies</i></h3>
<p>CREATE TABLE appraisal_replies ( id int(11) NOT NULL, staff_remarks varchar(255) NOT NULL DEFAULT '', staff_justifications text, lManager_remarks varchar(255) NOT NULL DEFAULT '', lManager_justification text, bManager_justification text, bManager_remarks varchar(255) NOT NULL DEFAULT '', stage varchar(100) NOT NULL DEFAULT '', date_created varchar(20) NOT NULL DEFAULT '', appraisal_id varchar(50) NOT NULL DEFAULT '', staff_id varchar(100) NOT NULL DEFAULT '', document_uploaded_by_staff varchar(255) NOT NULL DEFAULT '', admin_id varchar(255) NOT NULL DEFAULT '', comments_flow text NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>

<h3>Table structure for table <i> branches</i></h3>
<p>CREATE TABLE branches ( id int(11) NOT NULL, name varchar(255) NOT NULL DEFAULT '', address text NOT NULL, phone_number varchar(250) NOT NULL DEFAULT '', email varchar(255) NOT NULL, date_created varchar(255) NOT NULL, admin_id varchar(255) NOT NULL, insert_by varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;</p>

<h3>Table structure for table <i> certifications</i></h3>
<p>
CREATE TABLE certifications ( id int(11) NOT NULL, certification_name varchar(100) NOT NULL, date_cert varchar(100) NOT NULL, staff_id varchar(100) NOT NULL, admin_id varchar(255) NOT NULL, date_created varchar(255) NOT NULL, document varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>




<h3>Table structure for table <i> company</i></h3>
<p>
CREATE TABLE company ( id int(11) NOT NULL, company_name varchar(50) NOT NULL, admin_id varchar(20) DEFAULT NULL, department varchar(255) DEFAULT NULL, branch varchar(255) DEFAULT NULL, appraisal_flow text, requisition_flow text NOT NULL, leave_flow text, date_created varchar(255) NOT NULL, address varchar(255) NOT NULL, image varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> departments</i> </h3>
<p>
CREATE TABLE departments ( id int(255) NOT NULL, branch_id varchar(255) NOT NULL DEFAULT '', dept varchar(255) NOT NULL DEFAULT '', date_created varchar(255) NOT NULL DEFAULT '', admin_id varchar(255) NOT NULL, insert_by varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> employee_info </i></h3>
<p>
CREATE TABLE employee_info ( id int(50) NOT NULL, branch_id varchar(50) NOT NULL DEFAULT '', department_id varchar(50) DEFAULT '', first_name varchar(255) NOT NULL DEFAULT '', last_name varchar(255) NOT NULL DEFAULT '', date_of_birth varchar(255) NOT NULL DEFAULT '', status varchar(255) NOT NULL DEFAULT '', gender varchar(50) NOT NULL DEFAULT '', blood_type varchar(255) NOT NULL DEFAULT '', citizenship varchar(255) NOT NULL DEFAULT '', place_of_birth varchar(255) NOT NULL DEFAULT '', religion varchar(255) NOT NULL DEFAULT '', date_created varchar(255) NOT NULL DEFAULT '', middle_name varchar(255) NOT NULL DEFAULT '', employee_ID varchar(255) NOT NULL DEFAULT '', admin_id varchar(255) NOT NULL DEFAULT '', updated_by varchar(255) NOT NULL DEFAULT '', insert_by varchar(255) NOT NULL DEFAULT '', date_updated varchar(255) NOT NULL DEFAULT '' ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> employee_payroll_data </i></h3>
<p>
CREATE TABLE employee_payroll_data ( id int(255) NOT NULL, basic_salary varchar(255) NOT NULL DEFAULT '', employee_info_id varchar(255) NOT NULL, housing varchar(255) NOT NULL DEFAULT '', transport varchar(255) NOT NULL DEFAULT '', lunch varchar(255) NOT NULL DEFAULT '', utility varchar(255) NOT NULL DEFAULT '', education varchar(255) NOT NULL DEFAULT '', entertainment varchar(255) NOT NULL DEFAULT '', HMO varchar(255) NOT NULL DEFAULT '', leave_bonus varchar(255) NOT NULL DEFAULT '', xmas varchar(255) NOT NULL DEFAULT '', pension_company varchar(255) NOT NULL DEFAULT '', pension_earning varchar(255) NOT NULL DEFAULT '', tax varchar(255) NOT NULL DEFAULT '', gross varchar(255) NOT NULL DEFAULT '', service_charge varchar(255) NOT NULL DEFAULT '', VAT varchar(255) NOT NULL DEFAULT '', NET varchar(255) NOT NULL DEFAULT '', account_number varchar(255) NOT NULL DEFAULT '', bank_name varchar(255) NOT NULL DEFAULT '', insert_by varchar(255) NOT NULL DEFAULT '', date_created varchar(255) NOT NULL DEFAULT '', updated_by varchar(255) NOT NULL DEFAULT '', furniture varchar(255) NOT NULL DEFAULT '', q_allowance varchar(255) NOT NULL DEFAULT '', medical varchar(250) NOT NULL DEFAULT '', GLI varchar(250) NOT NULL DEFAULT '', ECA varchar(255) NOT NULL DEFAULT '', ITF varchar(255) NOT NULL DEFAULT '', NHF varchar(255) NOT NULL DEFAULT '' ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> id_card </i></h3>
<p>
CREATE TABLE id_card ( IID int(11) NOT NULL, staff_id varchar(100) NOT NULL, admin_id varchar(250) DEFAULT NULL, date_created varchar(250) DEFAULT NULL, signature varchar(250) DEFAULT NULL, status varchar(250) DEFAULT NULL, remark varchar(250) DEFAULT NULL, history varchar(250) DEFAULT NULL, cancel_request varchar(50) NOT NULL DEFAULT '', justification text NOT NULL, comment text NOT NULL ) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='ID Card Table';
</p>
<h3>Table structure for table <i> items </i></h3>
<p>
CREATE TABLE items ( id int(11) NOT NULL, item_category varchar(50) NOT NULL, item_cost varchar(150) NOT NULL, item_name varchar(250) NOT NULL, item_quantity varchar(50) NOT NULL, admin_id varchar(50) NOT NULL, date_created varchar(50) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> kss </i></h3>
<p>
CREATE TABLE kss ( id int(11) NOT NULL, information text, staff_id int(255) NOT NULL, admin_id int(255) NOT NULL, date_created varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> leaves</i></h3>
<p>
CREATE TABLE leaves ( id int(11) NOT NULL, company_name varchar(20) NOT NULL, leave_type varchar(20) NOT NULL, start_date varchar(20) NOT NULL, end_date varchar(20) NOT NULL, justification varchar(255) NOT NULL, require_reliever varchar(4) NOT NULL, reliever_source varchar(10) NOT NULL, reliever_name varchar(100) NOT NULL, reliever_email varchar(20) NOT NULL, reliever_phone varchar(20) NOT NULL, lManager_remark varchar(50) NOT NULL, bManager_remark varchar(50) NOT NULL, stage varchar(20) NOT NULL, status varchar(20) NOT NULL, date_created varchar(20) NOT NULL, staff_id varchar(20) NOT NULL, admin_id varchar(20) NOT NULL, fstage varchar(20) NOT NULL, flow text NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> open_information_portal</i></h3>
<p>
CREATE TABLE open_information_portal ( id int(11) NOT NULL, opening_date varchar(50) NOT NULL, closing_date varchar(50) NOT NULL, open_for varchar(255) NOT NULL, date_created varchar(50) NOT NULL, admin_id varchar(20) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> personal_information </i></h3>
<p>
CREATE TABLE personal_information ( id int(10) NOT NULL, surname varchar(20) NOT NULL, firstname varchar(20) NOT NULL, middlename varchar(20) NOT NULL, gender varchar(20) NOT NULL, DOB varchar(20) NOT NULL, town varchar(50) NOT NULL, state varchar(50) NOT NULL, country varchar(50) NOT NULL, staff_id varchar(11) NOT NULL, admin_id varchar(255) NOT NULL, date_created varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<h3>Table structure for table <i> qualifications</i></h3>
<p>
CREATE TABLE qualifications ( id int(11) NOT NULL, qualification_name varchar(50) NOT NULL, grade varchar(50) NOT NULL, institution varchar(100) NOT NULL, course_of_study varchar(50) NOT NULL, date_obtained varchar(50) NOT NULL, specialization varchar(255) NOT NULL, staff_id varchar(100) NOT NULL, admin_id varchar(255) NOT NULL, document varchar(250) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
</p>
<br><br>
<hr>
<p>
<strong> COPYRIGHT:</strong>

All titles, source codes, and other intellectual property rights in and to the SOFTWARE (including but not limited to any images, icons, button, design elements, video, audio, text and incorporated into the SOFTWARE), the accompanying printed materials, and any copies of the SOFTWARE, are owned by ICS outsourcing Limited.
</p>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="main-sidebar">

<div class="main-sidebar-container">


<div class="widget-block widget-block-posts">

<div class="widget-block-container">

<div class="widget-block-title">
<h6>Page Sections</h6>
</div>

<div class="widget-block-body">

<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#admin_settings" class="blog-item-small-title">Admin Settings</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#staff_settings"  class="blog-item-small-title">Staff Settings</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#dashboard"  class="blog-item-small-title">Dashboard</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#requisition"  class="blog-item-small-title">Requisition System</a>
</div>
</li>
</ul>
</div>
</div>

<div class="widget-block-container">
<div class="widget-block-title">
<h6>HR Core Pages</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="hrcore.php" class="blog-item-small-title">HRcore User Manual</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="hrcore2.php"  class="blog-item-small-title">HRcore Developer Document</a>
</div>
</li>
</ul>
</div>
</div>
</div>

</div>
</div>

</div>
</div>
</div>

<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>