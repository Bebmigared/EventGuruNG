<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
<style>
 table, th, td {
  border: 1px solid black;
  padding-left: 10px;
}
</style>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">Hotel Management - Developer Document</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="hma.php" title="hotel management">Hotel Management</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/hotel.png" alt="HR Core Article Image" />
</div>

<div class="blog-item-body">

<h2 id="introduction" class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">
<p><img class="alignleft" src="images/1/hotelApp_shoot/landingpage3.PNG" alt="HR Sign In" />Hotel management system is a platform that brings hotels around the world together for easy access to customers. <a href="https://www.hotelanywhere.com/login">https://www.hotelanywhere.com/login</a></p>
<br><br>
<h2 class="blog-item-title" id="task_status"><strong>TASK STATUS</strong></h2>
 
 <table>
<thead>
<tr><th>Modules</th><th>Status</th></tr>
</thead>
<tbody>
<tr><td>Landing  page</td><td>completed</td></tr>
<tr><td>Profile</td><td>completed</td></tr>
<tr><td>Dashboard</td><td>completed</td></tr>
<tr><td>Staff</td><td>completed</td></tr>
<tr><td>Room</td><td>completed</td></tr>
<tr><td>Booking</td><td>completed</td></tr>
<tr><td>maintanance management</td><td>in progress</td></tr>
<tr><td>account management</td><td>in progress</td></tr>
<tr><td>inventory management</td><td>in progress</td></tr>
</tbody>
</table>

</div>
</div>
</div>
</article>

<h3 id="breakdown"><strong>Code breakdown with language used</strong></h3>
<p><strong>Programming language:</strong> PHP, JavaScript, JQuery 
<br><strong> Database: MySQL</strong>
<br><strong> Version: 1.0.0 </strong>
<br><strong>System requirement:</strong> Browser compatibility: chrome, safari, internet explorer. 
<br> <strong>Processor Speed:</strong> Minimum Requirement, Pentium 4, 3.2 GHz or Power PC G5, 2.0 GHz. 
<br><strong>Memory:</strong> Minimum of 512 MB.</p>


<h3 id="db_structure"><strong>Database Structure</strong></h3>
<h3>Table structure for table <i> accounts</i></h3>
<p>
CREATE TABLE accounts ( id int(10) UNSIGNED NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>
<br>
<h3>Table structure for table  <i> amenities</i></h3>
<p>CREATE TABLE amenities ( id int(10) UNSIGNED NOT NULL, branchID varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, placesAround varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '', amenity varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL, wifi varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', swimmingpool varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', restaurant varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', bar varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', cinema varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>

<h3>Dumping data for table  <i> amenities</i></h3>
<p>INSERT INTO amenities (id, branchID, placesAround, amenity, created_at, updated_at, wifi, swimmingpool, restaurant, bar, cinema) VALUES (1, '8', 'Banks, cinema, Beach', '', '2019-03-18 20:01:35', '2019-03-18 20:25:54', 'Yes', 'Yes', 'Yes', 'Yes', 'Yes');</p>

<h3>Table structure for table  <i> branches</i></h3>
<p>
CREATE TABLE branches ( branchID int(10) NOT NULL, branchName varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, branchEmail varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, branchPhone varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, branchLoc varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL, branchAdd varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL, branch_image varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, aboutThebranch mediumtext COLLATE utf8mb4_unicode_ci NOT NULL, sadmin_id varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>


<h3>Table structure for table  <i> contact_infos</i></h3>
<p>
CREATE TABLE contact_infos ( id int(10) UNSIGNED NOT NULL, name varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, email varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, phone_number varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, message mediumtext COLLATE utf8mb4_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>
<h3>Table structure for table  <i> customer_reviews</i> </h3>
<p>
CREATE TABLE customer_reviews ( id int(10) UNSIGNED NOT NULL, comment varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, roomID varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, rating varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, date_created varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>
<h3>Table structure for table  <i> deals </i></h3>
<p>
CREATE TABLE deals ( id int(10) UNSIGNED NOT NULL, discount varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, deal_closingdate varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, branchID varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL, sadmin_id varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>
<p>
CREATE TABLE guests ( gID int(10) NOT NULL, gfname varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', glname varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', gemail varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', gphone varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', ggender varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', gaddress varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', gcity varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', gcountry varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', gIdNumber varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', gBranch int(9) DEFAULT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL, special_request mediumtext COLLATE utf8mb4_unicode_ci ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>
<h3>Table structure for table  <i> housekeepings </i></h3>
<p>
CREATE TABLE housekeepings ( id int(10) UNSIGNED NOT NULL, status varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, assigned_to varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, date_assigned varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>
<h3>Table structure for table <i> inventories </i></h3>
<p>
CREATE TABLE inventories ( id int(10) UNSIGNED NOT NULL, item_name varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, description mediumtext COLLATE utf8mb4_unicode_ci, quantity varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, location varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, price varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, purchase_year varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, date_created varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL, sadmin_id varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, updated_by varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, information varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, branch varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>
<h3>Table structure for table <i> maintenances </i></h3>
<p>
CREATE TABLE maintenances ( id int(10) UNSIGNED NOT NULL, category varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, work_assigned_to varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, priority varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, date_assigned varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, description varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, deadline varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, status varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, created_at timestamp NULL DEFAULT NULL, updated_at timestamp NULL DEFAULT NULL, room varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, branch varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>
<h3>Table structure for table  <i> migrations </i></h3>
<p>
CREATE TABLE migrations ( id int(10) UNSIGNED NOT NULL, migration varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, batch int(11) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
</p>

<br><br>
<hr>
<p>
<strong> COPYRIGHT:</strong>

All titles, source codes, and other intellectual property rights in and to the SOFTWARE (including but not limited to any images, icons, button, design elements, video, audio, text and incorporated into the SOFTWARE), the accompanying printed materials, and any copies of the SOFTWARE, are owned by ICS outsourcing Limited.
</p>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="main-sidebar">

<div class="main-sidebar-container">

<div class="widget-block-container">
<div class="widget-block-title">
<h6>HOTEL MANAGEMENT Documents</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="hrcore.php" class="blog-item-small-title">HOTEL MANAGEMENT User Manual</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="hrcore2.php"  class="blog-item-small-title">HOTEL MANAGEMENT Developer Document</a>
</div>
</li>
</ul>
</div>
</div>

<div class="widget-block widget-block-posts">

<div class="widget-block-container">

<div class="widget-block-title">
<h6>Page Sections</h6>
</div>

<div class="widget-block-body">

<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#introduction" class="blog-item-small-title">Introduction</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#task_status"  class="blog-item-small-title">Task Status</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#dashboard"  class="blog-item-small-title">Code Breakdown</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#db_structure"  class="blog-item-small-title">Database Structure</a>
</div>
</li>
</ul>
</div>
</div>


</div>

</div>
</div>

</div>
</div>
</div>

<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>