function play(){
  document.getElementById('vidwrap').innerHTML = '<iframe width="560" height="315" src="https://www.youtube.com/embed/ThFCg0tBDck?autoplay=1" frameborder="0" allowfullscreen></iframe>';
}

function play2(){
  document.getElementById('vidwrap2').innerHTML = '<iframe width="560" height="315" src="https://www.youtube.com/embed/ThFCg0tBDck?autoplay=1" frameborder="0" allowfullscreen></iframe>';
}

function play3(){
  document.getElementById('vidwrap3').innerHTML = '<iframe width="560" height="315" src="https://www.youtube.com/embed/ThFCg0tBDck?autoplay=1" frameborder="0" allowfullscreen></iframe>';
}