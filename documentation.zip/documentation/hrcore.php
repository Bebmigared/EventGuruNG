<?php
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">


<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="ICS_Outsourcing">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="description" content="ICS Outsourcing Software Documentation">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">HR Core - User Manual</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.php" title="Home"><i class="fa fa-home"></i></a></li>
<li><a href="hrcore.php" title="Blog">HR core</a></li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-right-sidebar">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-single-item">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<img src="images/blog/hrcore.png" alt="HR Core Article Image" />
</div>

<div class="blog-item-body">

<h2 class="blog-item-title"><strong>INTRODUCTION</strong></h2>

<div class="blog-item-description">
<p><img class="alignleft" src="images/1/shoot/signIn.PNG" alt="HR Sign In" />HRcore is a flexible software that helps with the day-to-day activities of the company. It includes leave management, appraisal management, requisition system, audit system. The URL to register as an admin is for HRcore is <a href="https://www.hrcore.ng/admin_register"  target="_blank"> https://www.hrcore.ng/admin_register</a> while the URL to register as a staff is <a href="https://www.hrcore.ng/register" target="_blank"> https://www.hrcore.ng/register .</a></p>
<blockquote>
<p>The hardest challenge being HR is that sometimes you have to be the LAWYER, the JUDGE and the HANGMAN. </p>
<footer>Hassan Choughari</footer>
</blockquote>
<h2 class="blog-item-title" id="admin_settings"><strong>SETTINGS</strong></h2>
 <p>In HRcore, the settings are a very important part of the HRcore. In the settings, the admin is first required to setup the system according to their company system specification by filling all fields correctly to enable easy flow of work.</p>
<h3><strong>Admin Settings</strong></h3>
<img src="images/1/shoot/admin_settings.PNG" alt="Admin settings 1"><br>
<img src="images/1/shoot/admin_setting2.PNG" alt="Admin settings 2"><br>
<img src="images/1/shoot/admin_setting3.PNG" alt="Admin settings 3">



<h3 id="staff_settings"><strong>Staff Settings</strong></h3>
<img src="images/1/shoot/staff_setting.PNG" alt="Staff settings 1"><br>
<img src="images/1/shoot/staff_settings2.PNG" alt="Staff settings 2"><br>

<p>Also the staff is also required to fill all fields on the settings for easy flow of request..</p>

<h3 id="dashboard"><strong>Dashboard</strong></h3>
<img src="images/1/shoot/dashboard.PNG" alt="Dashboard"><br><br>

<h3 id="requisition"><strong>Requisition System</strong></h3>
<img src="images/1/shoot/dashboard.PNG" alt="requisition_img"><br><br>
<p>
<strong>Under requisition, admin can</strong></p>

<ol>
    <li>Add items.</li>
    <li>View requested items</li>
    <li>Add inventory </li>
</ol>
<p>
<strong>While the staff can:</strong>
</p>
<ol>
    <li>View request items</li>
    <li>View requested items to follow the approval process.</li>
</ol>

<h3 id="admin"><strong>1. ADMIN: add item</strong></h3>
<img src="images/1/shoot/additem.PNG" alt="add_item_img"><br><br>

<h3 id="inventory"><strong>2. Inventory</strong></h3>
<img src="images/1/shoot/inventory.PNG" alt="Inventory_img"><br><br>

<h3 id="view_request"><strong>3. View Requested items</strong></h3>
<img src="images/1/shoot/requested.PNG" alt="View Request"><br><br>

<h3 id="view_request2"><strong>4. USER: Requested item</strong></h3>
<img src="images/1/shoot/user_request_item.PNG" alt="Requested_item_img"><br><br>



    
     While the admin can:
    

<h2 id="leave_mgmt"><strong>LEAVE MANAGEMENT SYSTEM</strong></h2>
<p>
In the leave management system, The staff can:
<ol>
    <li>Apply for leave</li>
    <li>USER: View the leave application</li>
    <li>ADMIN: View the leave application.</li>
</ol>
</p>

<h3 id="leave_request"><strong>leave request</strong></h3>
<img src="images/1/shoot/leave_request.PNG" alt="Leave_request_img_Main"><br><br>

<h3 id="view_leave"><strong>USER: View leave request</strong></h3>
<img src="images/1/shoot/show_leave.PNG" alt="Leave_request_img"><br>
<img src="images/1/shoot/user_view_leave.PNG" alt="Leave_request_img2"><br><br>

<h3 id="leave_details"><strong>leave details</strong></h3>
<img src="images/1/shoot/leave_details.PNG" alt="Leave_Details_img"><br><br>

<h2 id="appraisal">APPRASIAL SYSTEM</h2>
<p>
In the appraisal system, the admin can:
<ol>
    <li>Create appraisal either by uploading or input questions</li>
    <li>View appraisal. While the staff can:</li>
    <li>Perform appraisal.</li>
    <li>View appraisal.</li>

</ol>
</p>

<h3 id="create_appraisal"><strong>Create appraisal</strong></h3>
<img src="images/1/shoot/create_apparisal1.PNG" alt="Appraisal"><br><br>
<img src="images/1/shoot/create_apparisal2.PNG" alt="Appraisal2"><br><br>

<h3 id="view_appraisal"><strong>View appraisal</strong></h3>
<img src="images/1/shoot/apparisals.PNG" alt="Appraisal3"><br>
<img src="images/1/shoot/completed_apparisal.PNG" alt="Appraisal4"><br><br>


<h2 id="employee_info">EMPLOYEE INFORMATION SYSTEM</h2>
<p>On the platform, staff can view their information and also update their qualifications and work experience when the admin gives the permission.</p><br>
<h3><strong>Employee Information</strong></h3>
<img src="images/1/shoot/employee_info.PNG" alt="Employee_info_img"><br><br>

<h3 id="open_info"><strong>Admin open information portal</strong></h3>
<img src="images/1/shoot/employee_portal.PNG" alt="Admin_Portal_img"><br><br>

<h2 id="id_card">ID CARD REQUEST</h2>
<p>Staff can request for ID card and also follow the request. While the admin can view the request</p>

<h3 id="view_card"><strong>View ID card request</strong></h3>
<img src="images/1/shoot/idrequest.PNG" alt="ID_Request_img"><br><br>

<h3><strong>ID card request</strong></h3>
<img src="images/1/shoot/user_id_request.PNG" alt="ID_Card_request_img"><br><br>

<h2 id="directory">STAFF DIRECTORY</h2>
<p>This contains all staff necessary details.</p>

<h3><strong>Staff Directory</strong></h3>
<img src="images/1/shoot/directory.PNG" alt="Staff_Directory"><br><br>

<h2 id="kss_dashboard">KSS DASHBOARD</h2>
<p>The staff can post useful information and also view information that were posted.</p>

<h3 id="view_KSS"><strong>View KSS</strong></h3>
<img src="images/1/shoot/kss.PNG" alt="view_kss_img"><br><br>
<h3 id="post_KSS"><strong>Post KSS</strong></h3>
<img src="images/1/shoot/share_knowledge.PNG" alt="Post_kss_img"><br><br>

<h2 id="staff_audit">STAFF AUDIT</h2>
<p>Staff auditing is done in other to know the active staff in the company.</p>

<h3><strong>Staff Audit</strong></h3>
<img src="images/1/shoot/audit.PNG" alt="Staff_Audit"><br><br>

<h2 id="payroll">PAYROLL</h2>
<p>In the payroll, the account department can create the payment format for staff and also send the payment slip to the staff. They can also manage branch and department</p>
<h3><strong>Payroll</strong></h3>
<img src="images/1/shoot/payroll2.PNG" alt="Payroll"><br>
<img src="images/1/shoot/masterlist.PNG" alt="Payroll2"><br><br>

<h2>PAYSLIP</h2>
<h3><strong>Payslip</strong></h3>
<img src="images/1/shoot/payslip.PNG" alt="Payslip"><br><br>

<h2>PERMISSION</h2>
<p>Admin can grant permission to certain people or department to perform some actions under leave management, requisition system, leave management.</p>
<h3><strong>Permission</strong></h3>
<img src="images/1/shoot/permission1.PNG" alt="Permission_img"><br>
<img src="images/1/shoot/permission2.PNG" alt="Permission_img2"><br><br>
<img src="images/1/shoot/manage_dept.PNG" alt="Permission_img3"><br>
<img src="images/1/shoot/manage_branch.PNG" alt="Permission_img4"><br>

</div>
</div>
</div>
</article>



</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="main-sidebar">

<div class="main-sidebar-container">
<div class="widget-block widget-block-posts">

<div class="widget-block-container">
<div class="widget-block-title">
<h6>HR Core Documents</h6>
</div>

<div class="widget-block-body">
<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="hrcore.php" class="blog-item-small-title">HRcore User Manual</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="hrcore2.php"  class="blog-item-small-title">HRcore Developer Document</a>
</div>
</li>
</ul>
</div>
</div>


<div class="widget-block-container">
<div class="widget-block-title">
<h6>Page Sections</h6>
</div>

<div class="widget-block-body">

<ul class="blog-posts">
<li>
<div class="blog-item-body">
<a href="#admin_settings" class="blog-item-small-title">Admin Settings</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#staff_settings"  class="blog-item-small-title">Staff Settings</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#dashboard"  class="blog-item-small-title">Dashboard</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#requisition"  class="blog-item-small-title">Requisition System</a>
</div>
</li>

<li>
<div class="blog-item-body">
<a href="#admin"  class="blog-item-small-title">ADMIN: add item</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#inventory"  class="blog-item-small-title">Inventory</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_request"  class="blog-item-small-title">View Requested Items</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_request2"  class="blog-item-small-title">USER: Requested Item</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#leave_mgmt"  class="blog-item-small-title">Leave Management</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#leave_request"  class="blog-item-small-title">Leave Request</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_leave"  class="blog-item-small-title">USER: View Leave Request</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#leave_details"  class="blog-item-small-title">Leave Details</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#appraisal"  class="blog-item-small-title">Appraisal System</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#create_appraisal"  class="blog-item-small-title">Create Appraisal</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_appraisal"  class="blog-item-small-title">View Appraisal</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#employee_info"  class="blog-item-small-title">Employee Information</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#open_info"  class="blog-item-small-title">ADMIN: Open Information Portal</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#id_card"  class="blog-item-small-title">ID Card Request</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_card"  class="blog-item-small-title">View ID Card Request</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#directory"  class="blog-item-small-title">Staff Directory</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#kss_dashboard"  class="blog-item-small-title">KSS Dashboard</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#view_KSS"  class="blog-item-small-title">View KSS</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#post_KSS"  class="blog-item-small-title">Post KSS</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#staff_audit"  class="blog-item-small-title">Staff Audit</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#payroll"  class="blog-item-small-title">Payroll</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#payslip"  class="blog-item-small-title">Payslip</a>
</div>
</li>
<li>
<div class="blog-item-body">
<a href="#permission"  class="blog-item-small-title">Permission</a>
</div>
</li>

</ul>
</div>
</div>

</div>

</div>
</div>

</div>
</div>
</div>

<footer class="footer-section">
<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

<!-- Mirrored from graphicfort.com/templates/plume/blog-right-sidebar-single.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 25 Jul 2019 13:06:04 GMT -->
</html>