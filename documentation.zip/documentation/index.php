<?php 
session_start();
if(!isset($_SESSION['user'])){ //if login in session is not set
header("Location: signing/index.php");
}
?>
<!DOCTYPE html>
<html lang="en-US">

<head>

<title>ICS - Software Documentation</title>
<meta name="author" content="Graphicfort">
<meta name="robots" content="index follow">
<meta name="googlebot" content="index follow">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta name="keywords" content="PLUME, HTML5, CSS3, Creative, Multipurpose, Template, Create a website fast">
<meta name="description" content="HTML5 Multipurpose Template, Create a website fast">

<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="images/icons/favicon.png">
<link rel="apple-touch-icon" sizes="57x57" href="images/icons/apple-touch-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="images/icons/apple-touch-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="images/icons/apple-touch-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="images/icons/apple-touch-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="images/icons/apple-touch-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="images/icons/apple-touch-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="images/icons/apple-touch-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="images/icons/apple-touch-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="images/icons/apple-touch-icon-180x180.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CPoppins:400,500,600" rel="stylesheet">

<link rel="stylesheet" href="js/vendor/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="fonts/font-awesome/css/font-awesome.min.css">
<link rel="stylesheet" href="css/plugins.css">
<link rel="stylesheet" href="css/style.css">
<!--<link rel="stylesheet" href="css/responsive.css">

<script src="js/vendor/modernizr-custom.js"></script>-->
<style type="text/css">
	.img {
    height: 250px;
}
</style>
</head>

<body>

<a href="#" class="btn-gfort-top"><i class="fa fa-angle-up"></i></a>

<div id="main-wrapper">

<?php include 'header.php'; ?>

<div class="page-title-section page-title-section-wide grey-background-color">

<div class="section-container">

<div class="breadcrumb-title">

<div class="container">
<h1 class="breadcrumb-main-title">Documentation</h1>
</div>
</div>

<div class="breadcrumb-block">

<div class="container">
<ol class="breadcrumb">
<li><a href="index.html" title="Home"><i class="fa fa-home"></i></a></li>
<li class="active">...</li>
</ol>
</div>
</div>
</div>
</div>

<div class="page-body page-center">

<div class="main-content">

<div class="main-content-container">

<div class="gfort-section">

<div class="section-container">

<div class="container">

<div class="row">

<div class="col-md-12">

<div class="blog-items-wrapper blog-col-2">

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<a href="hrcore.php" target="_blank" title="HR Core" class="overlay-hover-2x scale-hover">
<img src="images/blog/thumbs/medium/hrcore.png" alt="Article Image" class="img" />
 </a>
</div>

<div class="blog-item-body">


<h2 class="blog-item-title">
<a href="hrcore.php" title="HRcore"><strong>HR CORE</strong></a>
</h2>

<div class="blog-item-description">
<p>HRcore is a flexible software that helps with the day-to-day activities of the company [...]</p>
</div>

<div class="blog-item-read-btn">
<a href="hrcore.php">Read more <i class="fa fa-long-arrow-right"></i></a>
</div>
</div>
</div>
</article>

<article class="blog-item format-image">

<div class="blog-item-container">

<div class="blog-item-media">
 <a href="hma.php" target="_blank" title="Hotel Management" class="overlay-hover-2x scale-hover" >
<img src="images/blog/thumbs/medium/hotel.png" alt="Article Image" class="img" />
</a>
</div>

<div class="blog-item-body">


<h2 class="blog-item-title">
<a href="hma.php" title="Hotel Management"><strong>Hotel Management</strong></a>
</h2>

<div class="blog-item-description">
<p>Hotel management system is a platform that brings hotels around the world[...]</p>
</div>

<div class="blog-item-read-btn">
<a href="hma.php">Read more <i class="fa fa-long-arrow-right"></i></a>
</div>
</div>
</div>
</article>

<article class="blog-item format-gallery">
 
<div class="blog-item-container">

<div class="blog-item-media">

<div class="gfort-owl-slider owl-carousel owl-theme" data-slider-items="1" data-slider-arrows="true" data-slider-dots="true" data-slider-dots-position="inside" data-slider-autoplay="true">

<div class="gfort-owl-slider-item">
<a href="pms.php" target="_blank" title="Preventive Maintenance Software" class="overlay-hover-2x scale-hover" >
<img src="images/blog/thumbs/medium/pms.png" alt="Article Image" class="img" />
</a>
</div>

<!--<div class="gfort-owl-slider-item">
<a href="images/blog/004.jpg" title="A great idea can make difference" class="overlay-hover-2x scale-hover" data-gfort-lightbox data-gfort-lightbox-group="gallery-1">
<img src="images/blog/thumbs/medium/004.jpg" alt="Article Image" />
</a>
</div>-->
</div>
</div>

<div class="blog-item-body">


<h2 class="blog-item-title">
<a href="pms.php" title="Preventive Maintenance Software"><strong>Preventive Maintenance Software</strong></a>
</h2>

<div class="blog-item-description">
<p>Preventive maintenance is maintenance exercise that is regularly performed on a piece of equipment[...]</p>
</div>

<div class="blog-item-read-btn">
<a href="pms.php">Read more <i class="fa fa-long-arrow-right"></i></a>
</div>
</div>
</div>
</article>

<article class="blog-item format-standard">

<div class="blog-item-container">

 <div class="blog-item-media">
<a href="smothride.php" target="_blank" title="SmoothRide" class="overlay-hover-2x scale-hover">
<img src="images/blog/thumbs/medium/smoothride.png" alt="Article Image" class="img" />
</a>
</div>

<div class="blog-item-body">

<h2 class="blog-item-title">
<a href="smothride.php" title="SmoothRide"><strong>SmoothRide</strong></a>
</h2>

<div class="blog-item-description">
<p>SmoothRide is an application that helps people connect with riders. It a B2B and pay as you go service. [...]</p>
</div>

<div class="blog-item-read-btn">
<a href="smothride.php">Read more <i class="fa fa-long-arrow-right"></i></a>
</div>
</div>
</div>
</article>

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<a href="fsa.php" target="_blank" title="Field Sales App" class="overlay-hover-2x scale-hover">
<img src="images/blog/thumbs/medium/fsa.png" alt="Article Image" class="img" />
</a>
</div>

<div class="blog-item-body">


<h2 class="blog-item-title">
<a href="fsa.php" title="Field Sales App"><strong>Field Sales App</strong></a>
</h2>

<div class="blog-item-description">
<p>Field sales is the process by which companies visit leads and sell to them in person. It enables the sales manager keep track of all their sales[...]</p>
</div>

<div class="blog-item-read-btn">
<a href="fsa.php">Read more <i class="fa fa-long-arrow-right"></i></a>
</div>
</div>
</div>
</article>

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<a href="ema.php" target="_blank" title="Event Management" class="overlay-hover-2x scale-hover">
<img src="images/blog/thumbs/medium/ema.png" alt="Article Image" class="img" />
</a>
</div>

<div class="blog-item-body">

<h2 class="blog-item-title">
<a href="ema.php" title="Event Management"><strong>Event Management</strong></a>
</h2>

<div class="blog-item-description">
<p>Event guru is an application on which people can create, search event, register for an event, connect with vendors[...]</p>
</div>

<div class="blog-item-read-btn">
<a href="ema.php">Read more <i class="fa fa-long-arrow-right"></i></a>
</div>
</div>
</div>
</article>

<article class="blog-item format-standard">

<div class="blog-item-container">

<div class="blog-item-media">
<a href="crm.php" target="_blank" title="Customer Relationship Management" class="overlay-hover-2x scale-hover">
<img src="images/blog/thumbs/medium/crm.png" alt="Article Image" class="img" />
</a>
</div>

<div class="blog-item-body">

<h2 class="blog-item-title">
<a href="crm.php" title="Customer Relationship Management"><strong>Customer Relationship Management</strong></a>
</h2>

<div class="blog-item-description">
<p>Customer Relationship Management (CRM) is a combination of strategies and technology that is used to analyse and manage customer[...]</p>
</div>

<div class="blog-item-read-btn">
<a href="crm.php">Read more <i class="fa fa-long-arrow-right"></i></a>
</div>
</div>
</div>
</article>

</div>

<div class="gfort-navigation-block">
<nav aria-label="Page navigation">
</nav>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<footer class="footer-section">


<div class="footer-copyright-section">

<div class="footer-copyright-section-container">

<div class="container">

<div class="row">

<div class="copyright-widget widget-left-side">

<div class="copyright-widget-container">

<div class="info-block">

<div class="info-block-container">
<p>&copy; 2019 <a href="http://www.icsoutsourcing.com" title="ICS Outsourcing" target="_blank">ICS Outsourcing</a>, all rights reserved.</p>
</div>
</div>
</div>
</div>

<div class="copyright-widget widget-right-side">

<div class="copyright-widget-container">

<div class="social-icons-block icons-transparent icons-sm icons-style-1">
<ul>
<li>
<a href="#" title="Facebook">
<i class="fa fa-facebook" aria-hidden="true"></i>
<i class="fa fa-facebook" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Google Plus">
<i class="fa fa-google-plus" aria-hidden="true"></i>
<i class="fa fa-google-plus" aria-hidden="true"></i>
 </a>
</li>
<li>
<a href="#" title="Twitter">
<i class="fa fa-twitter" aria-hidden="true"></i>
<i class="fa fa-twitter" aria-hidden="true"></i>
</a>
</li>
<li>
<a href="#" title="Linkedin">
<i class="fa fa-linkedin" aria-hidden="true"></i>
<i class="fa fa-linkedin" aria-hidden="true"></i>
</a>
</li>
</ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</footer>
</div>

<script type="text/javascript" src="js/vendor/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/vendor/jquery.min.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>
</body>

</html>